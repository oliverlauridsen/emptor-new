<?php wp_footer(); ?>

<footer><p> Copyright Emptor International Ldt. <br> All rights reserved.</p></footer>