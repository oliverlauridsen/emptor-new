// Loads splash screen on index.php
$(document).ready(function () {
	$("#moving").delay(2300).fadeOut(800);
	$("#loading_main_content").delay(2300).fadeOut(2000);
});
