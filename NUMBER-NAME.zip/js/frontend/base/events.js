// Will run when DOM is loaded
$(document).ready(function() {

    // Add your methods here
    projectFunctions.generalFunctions.init();

});

// Will run when the page is fully loaded - including graphics.
$(window).load(function() {

    // Add your methods here
    
});