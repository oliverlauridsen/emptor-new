<?php 
get_header();
wp_header();
?>

TEST 
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>404 - Page under construction</title>
</head>
<body>
    <section id="section_1">
        <div class="thankYouBlackOverlay">
        <nav id="desktop-nav">
            <a href="election.php">
            <img id="logo" src="../../build/images/Emptor_logo_white.png" alt="logo"> </a>
            <div id="header_line"> </div>
                
            <h1>
                <span id="404" style="font-size:75px" > 404 </span>
            </h1>
            <h1 id="possible"> 
                This site is under construction.
            </h1>
        </nav>
        <div class="thankyougoto">
        <a id="go_to" href="#">
                <span style="text-decoration: none"> You will be redirected briefly </span>
                <br>
              </a>
        </div>
    </div>
    </section>

<?php get_footer();?> 
</body>
</html>