<?php 
/* Template Name: Test */ 
?>

<!doctype html>
<html>

<head>
	<meta charset="UTF-8">
	<title> Security Seals - Seals in various material, colours, sizes and shapes </title>
	<meta name="description" content="Emptor International offers our clients well tested models of seals in various materials, colors, sizes and shapes. 
	Order your election kit now!">
	<link rel="stylesheet" href="../../build/css/main.css">
	<link href="https://fonts.googleapis.com/css?family=Quicksand:300,400,700" rel="stylesheet">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" type="text/css">
</head>

<body>
TEST
</body>

</html>